# Sub-Store 教程

# 简介

**适用于 Loon 、 Surge 和 Quantumult X 的高级订阅管理工具。完全本地解析，无订阅泄露的风险。**

# 主要功能

1. 订阅转换
2. 组合订阅
3. 订阅过滤
4. 订阅重命名
5. 订阅排序

# 反馈

**如果在使用过程中遇到问题，欢迎前往 Sub-Store 的 [GitHub](https://github.com/Peng-YM/Sub-Store) 仓库提出 PR 或 issue。**

[https://camo.githubusercontent.com/83ee1970f2c76ec12b9a0d62e3f2b924b3aa6e8d/68747470733a2f2f6769746875622d726561646d652d73746174732e76657263656c2e6170702f6170693f757365726e616d653d50656e672d594d2673686f775f69636f6e733d74727565](https://camo.githubusercontent.com/83ee1970f2c76ec12b9a0d62e3f2b924b3aa6e8d/68747470733a2f2f6769746875622d726561646d652d73746174732e76657263656c2e6170702f6170693f757365726e616d653d50656e672d594d2673686f775f69636f6e733d74727565)

# 注意事项

- 此教程利用 Loon 作为教学，Loon 与 Surge 有大部分相通之处，请用户自行参考。
- 请用户完整操作以下两个教程，否则 Sub-Store 无法发挥其应有的功能。
    1. 首次使用
    2. 单个订阅

# 更新日志（点击跳转至通知频道）

- 2020.09.03 更新
    1. [第四章中：将国旗/区旗操作移至节点操作](https://t.me/cool_scripts/224)
- 2020.09.04 更新
    1. [第五章中：新增节点高阶操作](https://t.me/cool_scripts/226)
    2. [第三章中：新增查看节点列表](https://t.me/cool_scripts/230)
- 2020.09.11 更新
    1. [第二章中：新增节点二维码分享](https://t.me/cool_scripts/236)
- 2020.09.18 更新
    
    1.[新增第七章：其他设置——云同步](https://t.me/cool_scripts/254)
    
- 2020.12.05 更新
    1. [第五章中：删除所有关于关键词的操作](https://t.me/cool_scripts/290)
- 2020.12.08 更新
    1. 说明：此次更新后，面板 UI 发生巨大变化，更新教程内图片会显得工程量巨大，因而此教程不会更新教程内图片
    2. [第七章中：云同步功能大更新](https://t.me/cool_scripts/292)
- 2020.12.09 更新
    1. [支持订阅图标自定义](https://t.me/cool_scripts/293)（[使用方法](https://t.me/cool_scripts/294)）

# 教程目录（点击跳转至教程）

[首次使用](https://www.notion.so/bd8b274bcc2b4ee9a4b8ca32434019a9)

1. [添加插件](https://www.notion.so/bbbe98a8858c48d795ce71b8906f7743)
2. [添加到主屏幕](https://www.notion.so/c53c417ece234f2ab6e08d6e183b13ba)

---

[单个订阅](https://www.notion.so/2cbc1f8376ac4c28965669c80937214e)

1. [Sub-Store 订阅](https://www.notion.so/Sub-Store-395a56d9640f4d728f869d2a201a2e56)
2. [Loon 订阅](https://www.notion.so/Loon-0ff80d65f9d242e7a0588995dba37f17)
3. [节点列表](https://www.notion.so/be489f25948c40a7a1cba67dc1120e63)
4. [节点分享](https://www.notion.so/e56c4f9090054dc0abd46c6dbdceb3ad)
5. [订阅图标](https://www.notion.so/66ea9c54e3ad468e867cd3253a7cb8c2)

---

[组合订阅](https://www.notion.so/19ba590eaccc46829d2eed5596bad8c5)

1. [Sub-Store 订阅](https://www.notion.so/Sub-Store-df9d6e4fe9e74895a1b50f0aedd336e6)
2. [Loon 订阅](https://www.notion.so/Loon-46220f6f39cd4cc999a4e5af6b291285)

---

[本地解析](https://www.notion.so/06daf4e7e1c34f4eb18b18df3bfe800b)

1. [支持功能](https://www.notion.so/756b90f0f24e489ca086e38570aade40)
2. [添加节点操作](https://www.notion.so/216d38cfba534e168cc4d8f481923e54)

---

[详讲本地解析](https://www.notion.so/dfc9e6ca21344444bbad07ceeb98ba68)

1. [过滤器](https://www.notion.so/52da684a4d324874a609e085ad91673a)
2. [节点排序](https://www.notion.so/ebd792a6f7034b0984ca1dc3df64a48d)
3. [重命名](https://www.notion.so/01748625e61d4583a3fdea3585d8a24c)
4. [删除名称](https://www.notion.so/0bb97b15d94d4b259d825e202685c58d)
5. [高阶操作](https://www.notion.so/76d8056f476d44cfa32ce486a86dc41a)

---

[订阅格式转换（未写）](https://www.notion.so/21bcab1df7264c958057e3c3b63647cc)

---

[其他设置](https://www.notion.so/b3f66fff9e774bff919695a598c9ff2e)

1.[申请 Token](https://www.notion.so/Token-835b2a80d4ae4e168405ec5ca054f9fd)

2.[云同步](https://www.notion.so/14b2459dc7e84f5181fccad9f51c8b3d)

3.[大更新（持续更新中）](https://www.notion.so/404ed0f765bf437c95aea72f906d8bf9)

---

[订阅配置分享](https://www.notion.so/294c12bd88664429867020af4d6e9661)

# 最后

感谢 Peng-YM 的辛勤付出！